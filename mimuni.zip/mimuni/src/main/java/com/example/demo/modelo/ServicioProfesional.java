package com.example.demo.modelo;



public class ServicioProfesional {

}
